﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using BaltBet_Server.Entity;

namespace BaltBet_Server
{
    // ПРИМЕЧАНИЕ. Команду "Переименовать" в меню "Рефакторинг" можно использовать для одновременного изменения имени интерфейса "IService1" в коде и файле конфигурации.
    [ServiceContract]
    public interface IBaltBat_Service
    {
        [OperationContract]
        void ChangeBalance(int IdAccount, decimal summ);

        [OperationContract]
        void AddStakeOrdinar(int IdEvent, decimal summ);

        [OperationContract]
        void AddSatakeExpress(int[] evntsID, decimal summ);

        [OperationContract]
        void AddSatakeSystem(int[] evntsID, int n, decimal summ);
        [OperationContract]
        void AddStakeSuperExpress(int IdSuperExpress, decimal summ);

        [OperationContract]
        decimal GetAccountBalance(int idAccount);

        [OperationContract]
        List<Stakes> GetStake(int IdStake);

        [OperationContract]
        List<Stakes> GetStakeForDate(DateTime date);


    }


    

    
       
    

}
