﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

using BaltBet_Server.Entity;

namespace BaltBet_Server
{
    public class Service1 : IBaltBat_Service
    {
        public decimal GetAccountBalance(int idAccount)
        {
            try
            {
                BaltBetEntities DB_Context = new BaltBetEntities();
                return DB_Context.Accounts.Where(a => a.ID == idAccount).FirstOrDefault().Balance;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        public void ChangeBalance(int IdAccount , decimal summ)//пополнение или снятие со счета
        {
            BaltBetEntities DB_Context = new BaltBetEntities();
            var account = DB_Context.Accounts.
                                Where(a => a.ID == IdAccount).FirstOrDefault();
            if (account == null)
                throw new Exception(String.Format("Не найден акканут с ID={0}", IdAccount));
            account.Balance += summ; //здесь можно вставить проверку на отрицательный баланс 
            DB_Context.SaveChanges();
        }

        public void AddStakeOrdinar(int IdEvent , decimal summ)//обычная ставка. коэф. равен коэф в событии
        {
            BaltBetEntities DB_Context = new BaltBetEntities();
            Events event_ = DB_Context.Events.
                                Where(e => e.IdEvent == IdEvent).FirstOrDefault();
            if (event_ == null)
                throw new Exception(String.Format("Не найдено событие с ID={0}", IdEvent));
            Stakes stake = new Stakes();
            stake.DateStake = DateTime.Now;
            stake.CoefStake = event_.CoefEvent;
            stake.SummStake = summ;
            stake.SummWin = summ * event_.CoefEvent;
            stake.Result = 0;
            DB_Context.Stakes.Add(stake);
            DB_Context.SaveChanges();
            DB_Context.StakeEventLinks.Add(new StakeEventLinks { toIdEvent = IdEvent, toIdStake = stake.ID });
            DB_Context.SaveChanges();
        }

        public void AddStakeSuperExpress(int IdSuperExpress, decimal summ)//Ставка на супер тираж. Ссылка на супер.тираж
        {
            BaltBetEntities DB_Context = new BaltBetEntities();
            Stakes stake = new Stakes();
            stake.DateStake = DateTime.Now;
            stake.CoefStake = 1;
            stake.SummStake = summ;
            stake.SummWin = summ;
            stake.Result = 0;
            DB_Context.Stakes.Add(stake);
            DB_Context.SaveChanges();
            DB_Context.StakeEventLinks.Add(new StakeEventLinks { toIdSuperEvent = IdSuperExpress, toIdStake = stake.ID });
            DB_Context.SaveChanges();
        }

        public void AddSatakeExpress(int[] evntsID , decimal summ)
        {
            BaltBetEntities DB_Context = new BaltBetEntities();
            decimal CoefStake = 1;
            foreach (Events e in DB_Context.Events.Where(e => evntsID.Contains(e.IdEvent)))//коэф. ставки равен коэф. всех событий
                CoefStake *= e.CoefEvent;

            Stakes stake = new Stakes();
            stake.DateStake = DateTime.Now;
            stake.CoefStake = CoefStake;
            stake.SummStake = summ;
            stake.SummWin = summ * CoefStake;
            stake.Result = 0;
            DB_Context.Stakes.Add(stake);
            DB_Context.SaveChanges();
            foreach (Events e in DB_Context.Events.Where(e => evntsID.Contains(e.IdEvent)))
                DB_Context.StakeEventLinks.Add(new StakeEventLinks { toIdEvent = e.IdEvent, toIdStake = stake.ID });
            DB_Context.SaveChanges();
        }


        private void Сombinations(int[] array,  int current, int max, List<List<int>> result) //переставляем все числа в массиве длинной комбинации max
        {
            if (result.Count == 0) //частный случай при первом запуске
            {
                result.Add(new List<int>());
            }
            if (max == 0) //частный случай
            {
                return;
            }
            var currentLevelResult = new List<int>(result.Last());
            for (int i = current; i < array.Length; ++i)
            {
                result.Last().Add(array[i]);
                if (result.Last().Count != max)
                {
                    Сombinations(array, i + 1, max, result);
                }
                result.Add(new List<int>(currentLevelResult));
            }
            if (result.Last().Count != max) //Если исходный массив закончился и в результате недостаточно элементов - удаляем такой результат
            {
                result.Remove(result.Last());
            }
        }
        public void AddSatakeSystem(int[] evntsID, int n , decimal summ)
        {
            int Factorial(int num)
            {
                return num <= 1 ? 1 : Enumerable.Range(1, num).Aggregate((i, j) => i * j);
            }
            if (evntsID.Length>16)
                throw new Exception("Количество событий в системе не должно быть больше 16");
            int countExpress = Factorial(evntsID.Length) / (Factorial(evntsID.Length - n) * Factorial(n));
            if (countExpress >1001)
                throw new Exception("Количество вариантов в системе не должно быть больше 1001");
            decimal sumStake = summ / countExpress;
            List<List<int>> systemComb = new List<List<int>>();
            Сombinations(evntsID, 0, n, systemComb);
            foreach (List<int> comb in systemComb)
                AddSatakeExpress(comb.ToArray(), sumStake);
        }

        public List<Stakes> GetStake(int IdStake)
        {
            BaltBetEntities DB_Context = new BaltBetEntities();
            return new List<Stakes>(DB_Context.Stakes.Where(s => s.ID == IdStake));
        }
        public List<Stakes> GetStakeForDate(DateTime date)
        {
            BaltBetEntities DB_Context = new BaltBetEntities();
            DateTime dateMax = date.AddDays(1).Date;//т.к. в поле DateStake используется время, то ищем от начала дня, до конца дня
            DateTime dateMin = date.Date;
            return new List<Stakes>(DB_Context.Stakes.Where(s =>s.DateStake>= dateMin && s.DateStake< dateMax));
        }

    }
}
