﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using BaltBat_Client.Balt_BetServer;

namespace BaltBat_Client
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private BaltBat_ServiceClient client;
        public MainWindow()
        {
            InitializeComponent();
            client = new BaltBat_ServiceClient();
        }

        private  void ShowBalance()
        {
            try
            {
                int idAccount = Convert.ToInt32(txtAccountID.Text);
                lbBalance.Content = "Баланс=" + client.GetAccountBalance(idAccount);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnAddBalance_Click(object sender, RoutedEventArgs e)
        {
            
            int idAccount = Convert.ToInt32(txtAccountID.Text);
            decimal summ = Convert.ToDecimal(txtAmount.Text);
            client.ChangeBalance(idAccount, summ);
            ShowBalance();
        }

        private void txtAccountID_LostFocus(object sender, RoutedEventArgs e)
        {
            ShowBalance();
        }

        private void btnAddBalance_Copy_Click(object sender, RoutedEventArgs e)
        {
            int idAccount = Convert.ToInt32(txtAccountID.Text);
            decimal summ = Convert.ToDecimal(txtAmount.Text);
            client.ChangeBalance(idAccount, -summ);
            ShowBalance();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int stakeID = Convert.ToInt32(txtStakeID.Text);
            Stakes[] stakes =  client.GetStake(stakeID);
            stakeGrid.ItemsSource = stakes;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            
            Stakes[] stakes = client.GetStakeForDate((DateTime)DtPicker.SelectedDate);
            stakeGrid.ItemsSource = stakes;
        }
    }
}
